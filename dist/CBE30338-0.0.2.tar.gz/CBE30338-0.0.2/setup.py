# following tutorial:
#     https://github.com/yngvem/python-project-structure
#     https://github.com/bast/somepackage

from setuptools import setup

setup()
